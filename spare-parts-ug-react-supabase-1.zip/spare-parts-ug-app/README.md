# Spare Parts UG — React + Supabase

A React/Vite recreation of the supplied `spare-parts-ug-demo.html`, with database-managed content and a private administrator area.

## Preserved from the supplied HTML

- Black / charcoal / red visual system (`#101012`, `#1B1B1E`, `#232327`, `#E31E24`, `#B8151A`), Rajdhani headings and Inter body text.
- Sticky header, hero with image overlay, location strip, category filters, two-column product grid, card badge treatment, `Why Spare Parts UG` band, footer, and floating WhatsApp link.
- The exact eight product names, category labels, starting image URLs and the page title from the uploaded HTML.
- The original product image aspect ratio (1:1) and the original product image crop for thumbnails. The lightbox uses `object-fit: contain` so the full image remains visible.

The cart drawer and cart interactions are intentionally not carried into the app: product enquiry buttons open WhatsApp directly, and each product enquiry tap is recorded. The uploaded file contains no `shield.js`, `Owner Preview Note`, or `Verified Preview` string, so none is present in this rebuild.

## 1. Configure Supabase

1. Create a Supabase project.
2. Open the SQL Editor and run `supabase/schema.sql`.
3. In **Authentication → Sign In / Providers → Email**, leave email/password enabled and turn **Confirm email** off. Supabase documents that disabling confirmation implicitly confirms newly created email users. Also turn **Allow new users to sign up** off so the public site has no registration flow. See [Supabase Auth configuration](https://supabase.com/docs/guides/auth/general-configuration).
4. In **Authentication → Users**, create the single administrator account using the email supplied by the owner and the password supplied separately in the conversation. Do not put that password in this project, source control, or a frontend environment variable.
5. Run `supabase/assign-admin.sql` in the SQL Editor. It assigns the `admin` database role to that Auth user and removes any other `admin` role row. A partial unique index also prevents more than one admin role from being present.
6. Copy the Project URL and anon/public key from **Project Settings → API**. Never use the `service_role` key in this frontend.

The frontend checks `user_roles` after password login. Database policies independently verify the same role through `public.is_admin()`; hiding admin pages in React is not the security boundary.

## 2. Configure the app

```bash
cp .env.example .env
```

Set the following values in `.env`:

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
VITE_CLOUDINARY_CLOUD_NAME=lgjllewt
VITE_CLOUDINARY_UPLOAD_PRESET=frecary
```

Only the Supabase anon/public key belongs in the browser. Do not add a Supabase service-role key or a Cloudinary API secret.

Install and run locally:

```bash
npm install
npm run dev
```

Build for production:

```bash
npm run build
```

The Vite output directory is `dist`. `netlify.toml` contains the build command, publish directory and SPA fallback redirect. Add the same four `VITE_...` variables in Netlify's site environment variables before deploying.

## 3. Configure Cloudinary uploads

The upload widget is wired to the Cloudinary cloud name and unsigned upload preset above. In Cloudinary, confirm that `frecary` is an **unsigned** preset. Restrict the preset to image formats and a sensible maximum file size. The widget opens from a user click and supports the device's local file picker and camera-capable mobile selection. On success, the returned HTTPS `secure_url` is saved to `product_images` or `site_settings.hero_image_url`.

Unsigned presets are public and can be abused by anyone who obtains the preset name. Apply upload restrictions in Cloudinary; never expose an API secret in this project. See [Cloudinary Upload Widget documentation](https://cloudinary.com/documentation/upload_widget).

## 4. Database behavior and RLS

`supabase/schema.sql` creates:

- `products` (including a `category` field so the original HTML's category filters remain database-driven, plus `badge_label` for the original card badges).
- `product_images` with ordered multi-image support.
- A singleton `site_settings` row for public copy, contact details, hero settings, filter labels, and the three existing “Why Spare Parts UG” items.
- `product_clicks`, with anonymous insert only for visible products and admin-only read access.
- `user_roles`, with no browser write policy. Role assignment is performed only from the Supabase SQL Editor.

Public access is limited to reading visible products, their images and the site settings, plus inserting product-click events. Product, image and settings writes require the DB-verified admin role. Click statistics are only readable by the admin.

### RLS smoke checks after setup

Run these checks from the Supabase SQL Editor using the role/JWT simulation facilities, or from the Supabase API with an anon client and a signed-in admin client:

1. Anonymous `SELECT` on `products` returns visible rows only.
2. Anonymous `SELECT` on `product_images` returns images only when their parent product is visible.
3. Anonymous `SELECT` on `site_settings` succeeds.
4. Anonymous `INSERT` on `product_clicks` for a visible product succeeds.
5. Anonymous `SELECT` on `product_clicks`, and anonymous insert/update/delete on products, images, settings or roles, fail.
6. A signed-in account without an `admin` row can read its own role row but cannot write products, images or settings or read clicks.
7. The configured admin can read all products and clicks, and can create/update/delete products, images and site settings.

Run `supabase/verify-policies.sql` as project owner to inspect the policy definitions, browser-role grants and admin-role count. The SQL includes the policies and grants; the live behavior checks still need to be run against the actual Supabase project because this source bundle does not have your project URL or keys.

## 5. Admin dashboard

- `/admin/login`: email/password sign-in only; no sign-up, customer account, reset or verification-email flow is exposed.
- `/admin`: product, stock, hidden-listing and 7/30-day WhatsApp tap stats; daily 30-day chart and top-five products.
- `/admin/products`: searchable/filterable table and mobile cards; add/edit, price, availability, visibility, reordering, delete confirmation and multi-photo upload/order.
- `/admin/content`: grouped editing for the visible homepage copy, category labels, contact/WhatsApp details, hero image, footer and existing benefits section. The footer address links to the configured Google Maps URL without adding a new visual block to the reference design.
- `/admin/account`: signed-in email and password-change form.

The modal does not set `body { overflow: hidden }`; the form itself is scrollable and closing paths do not leave a persistent body scroll lock. Per-row actions capture that row's product object/ID when rendered.

## 6. Important verification boundary

The source code and SQL setup are provided, but the project has not been connected to your Supabase account or Cloudinary console, deployed to Netlify, or exercised with your real admin session. The package installation attempt in this environment timed out, so a production `vite build` could not be completed here. JSX syntax was parsed/transpiled successfully for all source files, but that does not substitute for a dependency-resolved build or the live RLS, login, upload and mobile-device tests described above.
