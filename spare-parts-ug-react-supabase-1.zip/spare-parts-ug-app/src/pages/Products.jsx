import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Plus, Edit3, Trash2, Eye, EyeOff, ArrowUp, ArrowDown, Check, X, Package, Image as ImageIcon, GripVertical, LoaderCircle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import { formatUGX } from '../lib/format';
import CloudinaryUploadButton from '../components/CloudinaryUploadButton.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';

const EMPTY_FORM = { name: '', description: '', category: 'body', emoji_badge: '', badge_label: '', price: '', stock_status: 'in_stock', visible: true, images: [] };
const CATEGORIES = [
  { key: 'radios', label: 'Android / CarPlay Radio' },
  { key: 'body', label: 'Car Body Parts' },
  { key: 'security', label: 'Security System' },
  { key: 'facelift', label: 'Facelift Body Kit' },
];

export default function Products() {
  const [params, setParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [pendingImageIndex, setPendingImageIndex] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const refresh = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('products').select('*, product_images(*)').order('sort_order', { ascending: true });
    if (error) toast.error(error.message);
    else setProducts((data || []).map((p) => ({ ...p, product_images: [...(p.product_images || [])].sort((a, b) => a.sort_order - b.sort_order) })));
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);
  useEffect(() => { if (params.get('new') === '1' && !loading) { openCreate(); setParams({}); } }, [params, loading]);

  const filtered = useMemo(() => products.filter((p) => {
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(q);
    const matchesFilter = filter === 'all' || (filter === 'in_stock' && p.stock_status === 'in_stock' && p.visible) || (filter === 'out_of_stock' && p.stock_status === 'out_of_stock' && p.visible) || (filter === 'hidden' && !p.visible);
    return matchesQuery && matchesFilter;
  }), [products, query, filter]);

  const openCreate = () => { setEditing(null); setForm({ ...EMPTY_FORM }); setModalOpen(true); };
  const openEdit = (product) => {
    setEditing(product);
    setForm({ name: product.name || '', description: product.description || '', category: product.category || 'body', emoji_badge: product.emoji_badge || '', badge_label: product.badge_label || '', price: product.price ?? '', stock_status: product.stock_status || 'in_stock', visible: Boolean(product.visible), images: (product.product_images || []).map((img) => ({ id: img.id, url: img.image_url })) });
    setModalOpen(true);
  };
  const closeModal = () => { if (!saving) setModalOpen(false); };
  const change = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  const reorderImage = (index, direction) => setForm((current) => {
    const next = [...current.images]; const other = index + direction;
    if (other < 0 || other >= next.length) return current;
    [next[index], next[other]] = [next[other], next[index]]; return { ...current, images: next };
  });

  const saveProduct = async (event) => {
    event.preventDefault(); setSaving(true);
    const payload = {
      name: form.name.trim(), description: form.description.trim(), category: form.category,
      emoji_badge: form.emoji_badge.trim(), badge_label: form.badge_label.trim(),
      price: form.price === '' ? null : Number(form.price), stock_status: form.stock_status, visible: form.visible,
    };
    if (!payload.name || (payload.price !== null && (!Number.isFinite(payload.price) || payload.price < 0))) { toast.error('Enter a product name and a valid non-negative price.'); setSaving(false); return; }
    let productId = editing?.id;
    let result;
    if (editing) result = await supabase.from('products').update(payload).eq('id', editing.id).select('id').single();
    else result = await supabase.from('products').insert({ ...payload, sort_order: products.length ? Math.max(...products.map((p) => p.sort_order)) + 1 : 0 }).select('id').single();
    if (result.error) { toast.error(result.error.message); setSaving(false); return; }
    productId = result.data.id;
    const { error: removeError } = await supabase.from('product_images').delete().eq('product_id', productId);
    if (removeError) { toast.error(`Product saved, but previous image order could not be updated: ${removeError.message}`); setSaving(false); await refresh(); return; }
    const imagesPayload = form.images.map((img, index) => ({ product_id: productId, image_url: img.url, sort_order: index }));
    if (imagesPayload.length) {
      const { error: imageError } = await supabase.from('product_images').insert(imagesPayload);
      if (imageError) { toast.error(`Product saved, but images could not be linked: ${imageError.message}`); setSaving(false); await refresh(); return; }
    }
    toast.success(editing ? 'Product updated' : 'Product created');
    setSaving(false); setModalOpen(false); await refresh();
  };

  const toggleStock = async (product) => {
    setBusyId(product.id);
    const next = product.stock_status === 'in_stock' ? 'out_of_stock' : 'in_stock';
    const { error } = await supabase.from('products').update({ stock_status: next }).eq('id', product.id);
    if (error) toast.error(error.message); else { setProducts((list) => list.map((p) => p.id === product.id ? { ...p, stock_status: next } : p)); toast.success(next === 'in_stock' ? 'Marked in stock' : 'Marked out of stock'); }
    setBusyId(null);
  };
  const toggleVisible = async (product) => {
    setBusyId(product.id);
    const next = !product.visible;
    const { error } = await supabase.from('products').update({ visible: next }).eq('id', product.id);
    if (error) toast.error(error.message); else { setProducts((list) => list.map((p) => p.id === product.id ? { ...p, visible: next } : p)); toast.success(next ? 'Product is visible on the website' : 'Product hidden from the website'); }
    setBusyId(null);
  };
  const moveProduct = async (product, direction) => {
    const sorted = [...products].sort((a, b) => a.sort_order - b.sort_order);
    const index = sorted.findIndex((p) => p.id === product.id); const other = sorted[index + direction];
    if (!other) return;
    setBusyId(product.id);
    const firstOrder = product.sort_order; const secondOrder = other.sort_order;
    const [a, b] = await Promise.all([
      supabase.from('products').update({ sort_order: secondOrder }).eq('id', product.id),
      supabase.from('products').update({ sort_order: firstOrder }).eq('id', other.id),
    ]);
    if (a.error || b.error) toast.error(a.error?.message || b.error?.message);
    else { toast.success('Product order updated'); await refresh(); }
    setBusyId(null);
  };
  const deleteProduct = async () => {
    if (!deleteTarget) return; setDeleting(true);
    const { error } = await supabase.from('products').delete().eq('id', deleteTarget.id);
    if (error) toast.error(error.message); else { toast.success('Product deleted'); setProducts((list) => list.filter((p) => p.id !== deleteTarget.id)); }
    setDeleting(false); setDeleteTarget(null);
  };

  const ProductActions = ({ product, index, total }) => <div className="row-actions">
    <button title={product.stock_status === 'in_stock' ? 'Mark out of stock' : 'Mark in stock'} onClick={() => toggleStock(product)} disabled={busyId === product.id}><Check size={16} /></button>
    <button title={product.visible ? 'Hide product' : 'Show product'} onClick={() => toggleVisible(product)} disabled={busyId === product.id}>{product.visible ? <Eye size={16} /> : <EyeOff size={16} />}</button>
    <button title="Move up" onClick={() => moveProduct(product, -1)} disabled={index === 0 || busyId === product.id}><ArrowUp size={16} /></button>
    <button title="Move down" onClick={() => moveProduct(product, 1)} disabled={index === total - 1 || busyId === product.id}><ArrowDown size={16} /></button>
    <button title="Edit product" onClick={() => openEdit(product)}><Edit3 size={16} /></button>
    <button title="Delete product" className="danger-action" onClick={() => setDeleteTarget(product)}><Trash2 size={16} /></button>
  </div>;

  return <div className="page-content">
    <div className="page-heading"><div><p className="eyebrow">CATALOGUE MANAGEMENT</p><h1>Products</h1><p className="page-subtitle">Add parts, manage availability, update photos and control what customers see.</p></div><button className="btn btn-primary" onClick={openCreate}><Plus size={17} /> Add product</button></div>
    <div className="list-toolbar"><div className="search-input"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products…" /></div><div className="filter-pills">{[{ key: 'all', label: 'All' }, { key: 'in_stock', label: 'In stock' }, { key: 'out_of_stock', label: 'Out of stock' }, { key: 'hidden', label: 'Hidden' }].map((item) => <button key={item.key} className={filter === item.key ? 'selected' : ''} onClick={() => setFilter(item.key)}>{item.label}</button>)}</div><span className="result-count">{filtered.length} products</span></div>
    {loading ? <div className="panel table-loading">{[1,2,3,4,5].map((x) => <div key={x} className="table-skeleton-row" />)}</div> : !filtered.length ? <div className="panel empty-state"><Package size={32} /><strong>No products found</strong><span>Try a different search or filter, or add a new product.</span><button className="btn btn-primary" onClick={openCreate}><Plus size={16} /> Add product</button></div> : <>
      <div className="panel desktop-product-table"><table><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Visibility</th><th>Order</th><th>Actions</th></tr></thead><tbody>{filtered.map((p) => {
        const index = products.findIndex((item) => item.id === p.id); const thumb = p.product_images?.[0]?.image_url;
        return <tr key={p.id}><td><div className="product-cell">{thumb ? <img src={thumb} alt={p.name} loading="lazy" /> : <div className="table-no-image"><ImageIcon size={17} /></div>}<div><strong>{p.name}</strong><small>{p.description || CATEGORIES.find((c) => c.key === p.category)?.label || p.category}</small></div></div></td><td className="price-cell">{formatUGX(p.price)}</td><td><span className={`status-chip ${p.stock_status === 'in_stock' ? 'good' : 'warning'}`}>{p.stock_status === 'in_stock' ? 'In stock' : 'Out of stock'}</span></td><td><span className={`visibility-chip ${p.visible ? 'visible' : 'hidden'}`}>{p.visible ? 'Visible' : 'Hidden'}</span></td><td className="order-cell">{p.sort_order + 1}</td><td><ProductActions product={p} index={index} total={products.length} /></td></tr>;
      })}</tbody></table></div>
      <div className="mobile-product-list">{filtered.map((p) => {
        const index = products.findIndex((item) => item.id === p.id); const thumb = p.product_images?.[0]?.image_url;
        return <article className="mobile-product-card" key={p.id}><div className="mobile-product-top">{thumb ? <img src={thumb} alt={p.name} loading="lazy" /> : <div className="table-no-image"><ImageIcon size={18} /></div>}<div className="mobile-product-title"><strong>{p.name}</strong><small>{formatUGX(p.price)}</small><div className="mobile-statuses"><span className={`status-chip ${p.stock_status === 'in_stock' ? 'good' : 'warning'}`}>{p.stock_status === 'in_stock' ? 'In stock' : 'Out of stock'}</span><span className={`visibility-chip ${p.visible ? 'visible' : 'hidden'}`}>{p.visible ? 'Visible' : 'Hidden'}</span></div></div></div><ProductActions product={p} index={index} total={products.length} /></article>;
      })}</div>
    </>}

    {modalOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) closeModal(); }}><section className="product-modal" role="dialog" aria-modal="true" aria-labelledby="product-modal-title"><div className="modal-header"><div><p className="eyebrow">PRODUCT DETAILS</p><h2 id="product-modal-title">{editing ? 'Edit product' : 'Add product'}</h2></div><button className="icon-button" onClick={closeModal} disabled={saving} aria-label="Close"><X /></button></div>
      <form onSubmit={saveProduct} className="product-form">
        <label>Product name<input value={form.name} onChange={(e) => change('name', e.target.value)} required placeholder="e.g. Toyota Prado headlamp" /></label>
        <div className="form-two-cols"><label>Category<select value={form.category} onChange={(e) => change('category', e.target.value)}>{CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}</select></label><label>Card label / descriptor<input value={form.description} onChange={(e) => change('description', e.target.value)} placeholder="e.g. Car Body Parts" /></label></div>
        <div className="form-two-cols"><label>Emoji badge (optional)<input value={form.emoji_badge} onChange={(e) => change('emoji_badge', e.target.value)} placeholder="e.g. 🔦" /></label><label>Red image badge (optional)<input value={form.badge_label} onChange={(e) => change('badge_label', e.target.value)} placeholder="e.g. Popular" /></label></div>
        <div className="form-two-cols"><label>Price in UGX <span className="optional-label">Optional</span><input type="number" min="0" step="1" value={form.price} onChange={(e) => change('price', e.target.value)} placeholder="Leave empty for Contact for price" /></label><label>Stock status<select value={form.stock_status} onChange={(e) => change('stock_status', e.target.value)}><option value="in_stock">In stock</option><option value="out_of_stock">Out of stock</option></select></label></div>
        <div className="toggle-row"><div><strong>Visible on public website</strong><small>Hidden products remain in your admin catalogue.</small></div><button type="button" className={`switch ${form.visible ? 'on' : ''}`} role="switch" aria-checked={form.visible} onClick={() => change('visible', !form.visible)}><span /></button></div>
        <div className="images-editor"><div className="images-editor-head"><div><strong>Product photos</strong><small>First photo is the product card thumbnail. Reorder photos below.</small></div><CloudinaryUploadButton label="Add photo" folder="spare-parts-ug/products" onUploaded={(asset) => setForm((current) => ({ ...current, images: [...current.images, { url: asset.url }] }))} /></div>
          {form.images.length ? <div className="image-edit-list">{form.images.map((img, index) => <div className="image-edit-row" key={`${img.url}-${index}`}><span className="image-order"><GripVertical size={15} />{index + 1}</span><img src={img.url} alt={`Product photo ${index + 1}`} /><span className="image-url">{index === 0 ? 'Card thumbnail' : `Photo ${index + 1}`}</span><div><button type="button" onClick={() => reorderImage(index, -1)} disabled={index === 0} aria-label="Move photo earlier"><ArrowUp size={15} /></button><button type="button" onClick={() => reorderImage(index, 1)} disabled={index === form.images.length - 1} aria-label="Move photo later"><ArrowDown size={15} /></button><button type="button" className="danger-action" onClick={() => setPendingImageIndex(index)} aria-label="Remove photo"><Trash2 size={15} /></button></div></div>)}</div> : <div className="upload-empty"><ImageIcon size={24} /><span>No photos added yet.</span><small>Use Add photo to choose images from your phone or computer.</small></div>}
        </div>
        <div className="modal-actions"><button type="button" className="btn btn-light" onClick={closeModal} disabled={saving}>Cancel</button><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? <><LoaderCircle size={17} className="spin" /> Saving…</> : <><Check size={17} /> Save product</>}</button></div>
      </form>
    </section></div>}
    <ConfirmDialog open={pendingImageIndex !== null} title="Remove this photo?" message="This photo will be removed from the product gallery when you save the product." confirmLabel="Remove photo" onCancel={() => setPendingImageIndex(null)} onConfirm={() => { change('images', form.images.filter((_, i) => i !== pendingImageIndex)); setPendingImageIndex(null); }} />
    <ConfirmDialog open={Boolean(deleteTarget)} title="Delete this product?" message={deleteTarget ? `“${deleteTarget.name}” will be removed from the catalogue. Its linked image records and click history will also be deleted.` : ''} onCancel={() => setDeleteTarget(null)} onConfirm={deleteProduct} busy={deleting} />
  </div>;
}
