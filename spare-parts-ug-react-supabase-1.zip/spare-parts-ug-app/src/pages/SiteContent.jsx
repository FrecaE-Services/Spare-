import React, { useEffect, useState } from 'react';
import { ExternalLink, Save, Plus, Trash2, ArrowUp, ArrowDown, LoaderCircle, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import CloudinaryUploadButton from '../components/CloudinaryUploadButton.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';

const DEFAULTS = {
  business_name: '', logo_highlight: 'UG', header_cta_text: 'Enquire', hero_tag: '', hero_title: '', hero_description: '', hero_image_url: '', hero_primary_label: '', hero_secondary_label: '', hero_secondary_message: '', strip_location: '', primary_phone: '', secondary_phone: '', opening_hours: '', shop_address: '', footer_hours: '', footer_business_description: '', footer_credit: '', footer_copyright: '', whatsapp_number: '', whatsapp_greeting: '', general_whatsapp_message: "Hi Spare Parts UG, I'd like to enquire", maps_url: '', price_note: '', no_price_label: 'Contact for price', product_button_label: 'Enquire on WhatsApp', no_image_label: 'No image available', empty_products_label: 'No parts are listed in this category yet.', out_of_stock_badge_label: 'Out of Stock', footer_contact_heading: 'Visit / Contact', footer_phone_label: 'Call / WhatsApp:', category_filters: [], why_heading: '', why_items: [],
};

function Field({ label, value, onChange, multiline = false, help, type = 'text' }) {
  return <label className="content-field"><span>{label}</span>{multiline ? <textarea rows={3} value={value ?? ''} onChange={(e) => onChange(e.target.value)} /> : <input type={type} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />}{help && <small>{help}</small>}</label>;
}

export default function SiteContent() {
  const [form, setForm] = useState(DEFAULTS);
  const [settingsId, setSettingsId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [pendingRemoval, setPendingRemoval] = useState(null);
  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  useEffect(() => {
    let active = true;
    supabase.from('site_settings').select('*').eq('singleton', true).maybeSingle().then(({ data, error: loadError }) => {
      if (!active) return;
      if (loadError) setError(loadError.message);
      if (data) { setSettingsId(data.id); setForm({ ...DEFAULTS, ...data, category_filters: Array.isArray(data.category_filters) ? data.category_filters : [], why_items: Array.isArray(data.why_items) ? data.why_items : [] }); }
      setLoading(false);
    });
    return () => { active = false; };
  }, []);

  const save = async (event) => {
    event.preventDefault(); setSaving(true); setError('');
    const payload = { ...form, updated_at: new Date().toISOString() };
    delete payload.id;
    const query = settingsId
      ? supabase.from('site_settings').update(payload).eq('id', settingsId)
      : supabase.from('site_settings').insert({ ...payload, singleton: true });
    const { error: saveError } = await query;
    if (saveError) { setError(saveError.message); toast.error(saveError.message); }
    else toast.success('Website content saved');
    setSaving(false);
  };

  const updateWhy = (index, key, value) => update('why_items', form.why_items.map((item, i) => i === index ? { ...item, [key]: value } : item));
  const updateCategory = (index, key, value) => update('category_filters', form.category_filters.map((item, i) => i === index ? { ...item, [key]: value } : item));
  const confirmRemoval = () => {
    if (!pendingRemoval) return;
    const { listKey, index } = pendingRemoval;
    update(listKey, form[listKey].filter((_, i) => i !== index));
    setPendingRemoval(null);
  };
  const moveItem = (listKey, index, direction) => {
    const next = [...form[listKey]]; const other = index + direction;
    if (other < 0 || other >= next.length) return;
    [next[index], next[other]] = [next[other], next[index]]; update(listKey, next);
  };

  if (loading) return <div className="page-content"><div className="page-heading"><div><p className="eyebrow">PUBLIC WEBSITE</p><h1>Site content</h1></div></div><div className="content-skeleton" /></div>;
  return <div className="page-content">
    <div className="page-heading"><div><p className="eyebrow">PUBLIC WEBSITE</p><h1>Site content</h1><p className="page-subtitle">Edit the words, contact details and imagery displayed on the public store.</p></div><a className="btn btn-light" href="/" target="_blank" rel="noreferrer"><ExternalLink size={16} /> Preview website</a></div>
    {error && <div className="inline-alert">{error}</div>}
    <form className="site-content-form" onSubmit={save}>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Brand & header</h2><p>Business identity and the header enquiry link.</p></div></div><div className="content-fields-grid"><Field label="Business name" value={form.business_name} onChange={(v) => update('business_name', v)} /><Field label="Highlighted logo text" value={form.logo_highlight} onChange={(v) => update('logo_highlight', v)} /><Field label="Header button text" value={form.header_cta_text} onChange={(v) => update('header_cta_text', v)} /></div></section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Hero section</h2><p>The large image and headline at the top of the homepage.</p></div></div><div className="content-fields-grid"><Field label="Hero tag" value={form.hero_tag} onChange={(v) => update('hero_tag', v)} /><Field label="Hero headline" value={form.hero_title} onChange={(v) => update('hero_title', v)} /><Field label="Hero paragraph" value={form.hero_description} onChange={(v) => update('hero_description', v)} multiline /><Field label="Primary button text" value={form.hero_primary_label} onChange={(v) => update('hero_primary_label', v)} /><Field label="Secondary button text" value={form.hero_secondary_label} onChange={(v) => update('hero_secondary_label', v)} /><Field label="Secondary button WhatsApp message" value={form.hero_secondary_message} onChange={(v) => update('hero_secondary_message', v)} multiline /></div>
        <div className="hero-image-editor"><div className="hero-image-preview">{form.hero_image_url ? <img src={form.hero_image_url} alt="Current hero section" /> : <ImageIcon />}</div><div><strong>Hero background image</strong><small>Upload a wide image. It is stored in Cloudinary and its secure URL is saved here.</small><CloudinaryUploadButton label="Upload hero image" multiple={false} folder="spare-parts-ug/hero" onUploaded={(asset) => update('hero_image_url', asset.url)} /></div></div>
        <Field label="Hero image URL" value={form.hero_image_url} onChange={(v) => update('hero_image_url', v)} help="The upload control above fills this field automatically." />
      </section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Location strip & contact</h2><p>Details shown directly below the hero and in the footer.</p></div></div><div className="content-fields-grid"><Field label="Location strip text" value={form.strip_location} onChange={(v) => update('strip_location', v)} /><Field label="Primary phone number" value={form.primary_phone} onChange={(v) => update('primary_phone', v)} /><Field label="Secondary phone number" value={form.secondary_phone} onChange={(v) => update('secondary_phone', v)} /><Field label="Opening hours (strip)" value={form.opening_hours} onChange={(v) => update('opening_hours', v)} /><Field label="Full shop address" value={form.shop_address} onChange={(v) => update('shop_address', v)} /><Field label="Opening hours (footer)" value={form.footer_hours} onChange={(v) => update('footer_hours', v)} /><Field label="Google Maps link" value={form.maps_url} onChange={(v) => update('maps_url', v)} /></div></section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>WhatsApp enquiries</h2><p>WhatsApp is the ordering and enquiry channel for every product.</p></div></div><div className="content-fields-grid"><Field label="WhatsApp number (international format)" value={form.whatsapp_number} onChange={(v) => update('whatsapp_number', v)} help="Example: 256774188097" /><Field label="Product enquiry greeting" value={form.whatsapp_greeting} onChange={(v) => update('whatsapp_greeting', v)} multiline help="The product name and vehicle details prompt are added automatically." /><Field label="General WhatsApp message" value={form.general_whatsapp_message} onChange={(v) => update('general_whatsapp_message', v)} multiline help="Used by the header and floating WhatsApp links." /><Field label="Price note below product prices" value={form.price_note} onChange={(v) => update('price_note', v)} /><Field label="Text when no price is set" value={form.no_price_label} onChange={(v) => update('no_price_label', v)} /><Field label="Product WhatsApp button text" value={form.product_button_label} onChange={(v) => update('product_button_label', v)} /><Field label="Out-of-stock badge text" value={form.out_of_stock_badge_label} onChange={(v) => update('out_of_stock_badge_label', v)} /><Field label="No image placeholder text" value={form.no_image_label} onChange={(v) => update('no_image_label', v)} /><Field label="Empty category message" value={form.empty_products_label} onChange={(v) => update('empty_products_label', v)} multiline /></div></section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Product category filters</h2><p>These filter labels appear above the product grid. Each key maps to the product category key.</p></div><button type="button" className="subtle-button" onClick={() => update('category_filters', [...form.category_filters, { key: `category-${Date.now()}`, label: 'New category' }])}><Plus size={15} /> Add category</button></div>
        <div className="repeat-list">{form.category_filters.map((cat, index) => <div className="repeat-row" key={`${cat.key}-${index}`}><Field label="Category key" value={cat.key} onChange={(v) => updateCategory(index, 'key', v)} /><Field label="Visible label" value={cat.label} onChange={(v) => updateCategory(index, 'label', v)} /><div className="repeat-controls"><button type="button" onClick={() => moveItem('category_filters', index, -1)} disabled={index === 0}><ArrowUp size={15} /></button><button type="button" onClick={() => moveItem('category_filters', index, 1)} disabled={index === form.category_filters.length - 1}><ArrowDown size={15} /></button><button type="button" className="danger-action" onClick={() => setPendingRemoval({ listKey: 'category_filters', index, label: cat.label })}><Trash2 size={15} /></button></div></div>)}</div>
      </section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Why Spare Parts UG</h2><p>The three benefit statements in the lower content band.</p></div><button type="button" className="subtle-button" onClick={() => update('why_items', [...form.why_items, { title: '', description: '' }])}><Plus size={15} /> Add item</button></div><Field label="Section heading" value={form.why_heading} onChange={(v) => update('why_heading', v)} />
        <div className="repeat-list">{form.why_items.map((item, index) => <div className="why-edit-row" key={index}><div className="repeat-row-label">Benefit {index + 1}</div><Field label="Title" value={item.title} onChange={(v) => updateWhy(index, 'title', v)} /><Field label="Description" value={item.description} onChange={(v) => updateWhy(index, 'description', v)} multiline /><div className="repeat-controls"><button type="button" onClick={() => moveItem('why_items', index, -1)} disabled={index === 0}><ArrowUp size={15} /></button><button type="button" onClick={() => moveItem('why_items', index, 1)} disabled={index === form.why_items.length - 1}><ArrowDown size={15} /></button><button type="button" className="danger-action" onClick={() => setPendingRemoval({ listKey: 'why_items', index, label: item.title || `Benefit ${index + 1}` })}><Trash2 size={15} /></button></div></div>)}</div>
      </section>
      <section className="panel content-section"><div className="content-section-heading"><div><h2>Footer</h2><p>Public footer wording and credit line.</p></div></div><div className="content-fields-grid"><Field label="Footer business description" value={form.footer_business_description} onChange={(v) => update('footer_business_description', v)} multiline /><Field label="Footer contact heading" value={form.footer_contact_heading} onChange={(v) => update('footer_contact_heading', v)} /><Field label="Footer phone label" value={form.footer_phone_label} onChange={(v) => update('footer_phone_label', v)} /><Field label="Copyright text" value={form.footer_copyright} onChange={(v) => update('footer_copyright', v)} /><Field label="Site credit" value={form.footer_credit} onChange={(v) => update('footer_credit', v)} /></div></section>
      <div className="sticky-save-bar"><span>Changes only appear on the public website after saving.</span><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? <LoaderCircle className="spin" size={17} /> : <Save size={17} />}{saving ? 'Saving…' : 'Save site content'}</button></div>
    </form>
    <ConfirmDialog open={Boolean(pendingRemoval)} title="Remove this content item?" message={pendingRemoval ? `“${pendingRemoval.label}” will be removed from this editor. The public website changes after you save.` : ''} confirmLabel="Remove item" onCancel={() => setPendingRemoval(null)} onConfirm={confirmRemoval} />
  </div>;
}
