import React, { useEffect, useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { LockKeyhole, ArrowLeft, LoaderCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import { toast } from 'sonner';

export default function Login() {
  const { session, role, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (session && role === 'admin' && !loading) navigate('/admin', { replace: true });
  }, [session, role, loading, navigate]);

  if (loading) return <div className="admin-loading-screen"><div className="loading-mark">SP</div><p>Loading secure sign-in…</p></div>;
  if (session && role === 'admin') return <Navigate to="/admin" replace />;

  const handleSubmit = async (event) => {
    event.preventDefault(); setBusy(true); setError('');
    const { data, error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (authError) { setError(authError.message); setBusy(false); return; }
    const { data: roleData, error: roleError } = await supabase.from('user_roles').select('role').eq('user_id', data.user.id).maybeSingle();
    if (roleError || roleData?.role !== 'admin') {
      await supabase.auth.signOut();
      const message = roleError?.message || 'This account is not authorized as the store administrator.';
      setError(message); setBusy(false); return;
    }
    toast.success('Welcome back');
    navigate(location.state?.from?.startsWith('/admin') ? location.state.from : '/admin', { replace: true });
    setBusy(false);
  };

  return <main className="login-screen"><div className="login-card">
    <Link to="/" className="login-back"><ArrowLeft size={16} /> Back to store</Link>
    <div className="login-mark">SP</div><p className="login-kicker">SPARE PARTS UG</p><h1>Admin sign in</h1><p className="login-subtitle">Sign in to manage products, store content and enquiries.</p>
    {error && <div className="form-error" role="alert">{error}</div>}
    <form onSubmit={handleSubmit} className="login-form">
      <label>Email address<input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@example.com" required /></label>
      <label>Password<input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required /></label>
      <button className="btn btn-primary login-submit" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={18} /> : <LockKeyhole size={17} />}{busy ? 'Signing in…' : 'Sign in securely'}</button>
    </form>
    <p className="login-footnote">Authorized administrator access only. There is no public registration.</p>
  </div></main>;
}
