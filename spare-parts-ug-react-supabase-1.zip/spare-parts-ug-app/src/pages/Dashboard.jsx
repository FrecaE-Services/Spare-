import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, CheckCircle2, AlertCircle, EyeOff, MousePointerClick, CalendarDays, Plus, FilePenLine, ArrowUpRight } from 'lucide-react';
import { BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { subDays, format, startOfDay } from 'date-fns';
import { supabase } from '../lib/supabase';
import { formatUGX } from '../lib/format';

const EMPTY = { total: 0, inStock: 0, outStock: 0, hidden: 0, taps7: 0, taps30: 0 };
export default function Dashboard() {
  const [stats, setStats] = useState(EMPTY);
  const [daily, setDaily] = useState([]);
  const [top, setTop] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    async function load() {
      setLoading(true); setError('');
      const now = new Date();
      const since30 = subDays(startOfDay(now), 29).toISOString();
      const since7 = subDays(startOfDay(now), 6).toISOString();
      const [productResult, clickResult] = await Promise.all([
        supabase.from('products').select('id,name,stock_status,visible,price,sort_order'),
        supabase.from('product_clicks').select('id,product_id,created_at').gte('created_at', since30).order('created_at', { ascending: true }),
      ]);
      if (!active) return;
      if (productResult.error || clickResult.error) setError(productResult.error?.message || clickResult.error?.message || 'Could not load dashboard data.');
      const products = productResult.data || [];
      const clicks = clickResult.data || [];
      const tap7 = clicks.filter((c) => new Date(c.created_at) >= new Date(since7)).length;
      const dailyMap = new Map();
      for (let i = 0; i < 30; i += 1) {
        const day = subDays(startOfDay(now), 29 - i);
        dailyMap.set(format(day, 'yyyy-MM-dd'), { day: format(day, 'dd MMM'), taps: 0 });
      }
      clicks.forEach((click) => {
        const key = format(new Date(click.created_at), 'yyyy-MM-dd');
        if (dailyMap.has(key)) dailyMap.get(key).taps += 1;
      });
      const counts = new Map();
      clicks.forEach((click) => counts.set(click.product_id, (counts.get(click.product_id) || 0) + 1));
      const topProducts = [...products].map((p) => ({ ...p, taps: counts.get(p.id) || 0 })).sort((a, b) => b.taps - a.taps).slice(0, 5);
      setStats({ total: products.length, inStock: products.filter((p) => p.stock_status === 'in_stock').length, outStock: products.filter((p) => p.stock_status === 'out_of_stock').length, hidden: products.filter((p) => !p.visible).length, taps7: tap7, taps30: clicks.length });
      setDaily([...dailyMap.values()]); setTop(topProducts); setLoading(false);
    }
    load(); return () => { active = false; };
  }, []);

  const cards = useMemo(() => [
    { label: 'Total products', value: stats.total, icon: Package, detail: 'All catalogue items', kind: 'dark' },
    { label: 'In stock', value: stats.inStock, icon: CheckCircle2, detail: 'Available listings', kind: 'green' },
    { label: 'Out of stock', value: stats.outStock, icon: AlertCircle, detail: 'Unavailable listings', kind: 'orange' },
    { label: 'Hidden', value: stats.hidden, icon: EyeOff, detail: 'Not shown publicly', kind: 'gray' },
    { label: 'WhatsApp taps · 7 days', value: stats.taps7, icon: MousePointerClick, detail: 'Product enquiry clicks', kind: 'green' },
    { label: 'WhatsApp taps · 30 days', value: stats.taps30, icon: CalendarDays, detail: 'Product enquiry clicks', kind: 'orange' },
  ], [stats]);

  return <div className="page-content">
    <div className="page-heading"><div><p className="eyebrow">STORE PERFORMANCE</p><h1>Overview</h1><p className="page-subtitle">A quick view of your product catalogue and customer interest.</p></div><div className="heading-actions"><Link className="btn btn-primary" to="/admin/products?new=1"><Plus size={17} /> Add product</Link><Link className="btn btn-light" to="/admin/content"><FilePenLine size={17} /> Edit site text</Link></div></div>
    {error && <div className="inline-alert">{error}</div>}
    <div className="stats-grid">{cards.map(({ label, value, icon: Icon, detail, kind }) => <div className="stat-card" key={label}><div className={`stat-icon ${kind}`}><Icon size={19} /></div><div className="stat-label">{label}</div><div className="stat-value">{loading ? <span className="skeleton-number" /> : value}</div><div className="stat-detail">{detail}</div></div>)}</div>
    <div className="dashboard-grid">
      <section className="panel chart-panel"><div className="panel-heading"><div><h2>WhatsApp taps</h2><p>Daily product enquiries over the last 30 days</p></div><span className="panel-pill">Last 30 days</span></div>
        {loading ? <div className="chart-skeleton" /> : <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><BarChart data={daily} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEF0F3" /><XAxis dataKey="day" tick={{ fontSize: 10, fill: '#7B8490' }} interval={4} axisLine={false} tickLine={false} /><YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#7B8490' }} axisLine={false} tickLine={false} /><Tooltip cursor={{ fill: '#FFF2EA' }} contentStyle={{ border: '1px solid #E9EDF1', borderRadius: 10, fontSize: 12 }} /><Bar dataKey="taps" fill="#E31E24" radius={[4, 4, 0, 0]} maxBarSize={22} /></BarChart></ResponsiveContainer></div>}
      </section>
      <section className="panel top-panel"><div className="panel-heading"><div><h2>Most tapped products</h2><p>Ranked by product WhatsApp taps over the last 30 days</p></div><Link className="text-link" to="/admin/products">View all <ArrowUpRight size={14} /></Link></div>
        {loading ? <div className="top-skeleton">{[1,2,3,4,5].map((n) => <div key={n} />)}</div> : top.length ? <div className="top-list">{top.map((p, index) => <div className="top-row" key={p.id}><span className="rank-number">{index + 1}</span><div className="top-product"><strong>{p.name}</strong><small>{p.stock_status === 'in_stock' ? 'In stock' : 'Out of stock'} · {p.visible ? 'Visible' : 'Hidden'}</small></div><span className="tap-count">{p.taps} <small>taps</small></span></div>)}</div> : <div className="empty-state compact"><MousePointerClick size={24} /><strong>No product taps yet</strong><span>Enquiries will appear here as customers tap WhatsApp.</span></div>}
      </section>
    </div>
    <div className="dashboard-footnote">Prices shown in the public store are maintained in UGX. {stats.total ? `The catalogue currently contains ${stats.total} product listings.` : ''}</div>
  </div>;
}
