import React, { useState } from 'react';
import { KeyRound, ShieldCheck, LoaderCircle } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';

export default function Account() {
  const { user } = useAuth();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async (event) => {
    event.preventDefault(); setError('');
    if (password.length < 8) { setError('Use a password with at least 8 characters.'); return; }
    if (password !== confirm) { setError('The password confirmation does not match.'); return; }
    setBusy(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    if (updateError) { setError(updateError.message); toast.error(updateError.message); }
    else { toast.success('Password updated successfully'); setPassword(''); setConfirm(''); }
    setBusy(false);
  };
  return <div className="page-content"><div className="page-heading"><div><p className="eyebrow">SECURITY & ACCESS</p><h1>Account</h1><p className="page-subtitle">Your administrator sign-in details and password settings.</p></div></div>
    <section className="panel account-card"><div className="account-card-icon"><ShieldCheck size={22} /></div><div><p className="eyebrow">SIGNED IN AS</p><h2>{user?.email}</h2><p className="account-help">This account has administrator access through the database user_roles table.</p></div><span className="status-chip good">Admin</span></section>
    <section className="panel password-panel"><div className="content-section-heading"><div><h2><KeyRound size={19} /> Change password</h2><p>Choose a strong password and keep it private.</p></div></div>{error && <div className="form-error">{error}</div>}<form onSubmit={submit} className="password-form"><label>New password<input type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} /></label><label>Confirm new password<input type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required minLength={8} /></label><button className="btn btn-primary" type="submit" disabled={busy}>{busy ? <LoaderCircle size={17} className="spin" /> : <KeyRound size={17} />}{busy ? 'Updating…' : 'Update password'}</button></form></section>
  </div>;
}
