import React from 'react';
import { Link } from 'react-router-dom';
export default function NotFound() { return <main className="not-found"><div className="not-found-mark">SP</div><p className="not-found-kicker">SPARE PARTS UG</p><h1>404</h1><h2>Page not found</h2><p>The page you are looking for may have moved or no longer exists.</p><Link to="/" className="btn btn-primary">Return to store</Link></main>; }
