import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { buildWhatsAppUrl, formatUGX } from '../lib/format';
import { X, ChevronLeft, ChevronRight, MessageCircle } from 'lucide-react';

const FALLBACK_SETTINGS = {
  business_name: 'Spare Parts UG', logo_highlight: 'UG', header_cta_text: 'Enquire',
  hero_tag: 'No.1 Automotive Spare Parts Mega Store', hero_title: 'Your Reliable Auto Parts Partner.',
  hero_description: 'Car facelifting, body parts, Android radios, security systems, and every accessory in between — genuine parts, fitted to your exact model.',
  hero_image_url: 'https://images.unsplash.com/photo-1648892936786-de40bb1080a6?w=1200&auto=format&fit=crop&q=80',
  hero_primary_label: 'Shop Parts', hero_secondary_label: 'Ask a Specialist', hero_secondary_message: 'Hi Spare Parts UG, I need help finding a part',
  strip_location: 'William Street, Kampala', primary_phone: '0774 188097', secondary_phone: '0752 127553', opening_hours: 'Open 8:30 AM – 6:00 PM',
  shop_address: 'William Street, Kampala, Uganda', footer_hours: 'Open Mon–Sat, 8:30 AM – 6:00 PM',
  footer_business_description: 'Your reliable auto parts partner for quality car parts, facelifts, and accessories.',
  footer_credit: 'Site by FRECA E-SERVICES — Frontend Demo', footer_copyright: '© 2026 Spare Parts UG',
  whatsapp_number: '256774188097', whatsapp_greeting: 'Hi Spare Parts UG! I saw your website. I am interested in: ', general_whatsapp_message: "Hi Spare Parts UG, I'd like to enquire",
  maps_url: 'https://www.google.com/maps/search/?api=1&query=William+Street+Kampala+Uganda', price_note: 'Sample listing — confirm with real menu',
  no_price_label: 'Contact for price', product_button_label: 'Enquire on WhatsApp', no_image_label: 'No image available', empty_products_label: 'No parts are listed in this category yet.', out_of_stock_badge_label: 'Out of Stock', footer_contact_heading: 'Visit / Contact', footer_phone_label: 'Call / WhatsApp:',
  category_filters: [{ key: 'all', label: 'All Parts' }, { key: 'radios', label: 'Android / CarPlay Radios' }, { key: 'body', label: 'Car Body Parts' }, { key: 'security', label: 'Security Systems' }, { key: 'facelift', label: 'Facelift Body Kits' }],
  why_heading: 'Why Spare Parts UG', why_items: [
    { title: 'Model-Specific Fit', description: 'Radios and parts listed by exact make, model, and year — no guesswork.' },
    { title: '3,000+ Followers Strong', description: 'A trusted name across Kampala for facelifts, body parts, and upgrades.' },
    { title: 'One Stop Shop', description: 'From headlamps to GPS trackers — everything your car needs, in one place.' },
  ],
};

function PhoneLink({ phone, children }) {
  const tel = String(phone || '').replace(/[^+\d]/g, '');
  return <a href={`tel:${tel}`}>{children || phone}</a>;
}

export default function PublicSite() {
  const [settings, setSettings] = useState(FALLBACK_SETTINGS);
  const [products, setProducts] = useState([]);
  const [activeCategory, setActiveCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [lightbox, setLightbox] = useState(null);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      const [settingsResult, productsResult] = await Promise.all([
        supabase.from('site_settings').select('*').eq('singleton', true).maybeSingle(),
        supabase.from('products').select('*, product_images(*)').eq('visible', true).order('sort_order', { ascending: true }),
      ]);
      if (!mounted) return;
      if (settingsResult.error || productsResult.error) {
        setLoadError(settingsResult.error?.message || productsResult.error?.message || 'Unable to load the live store.');
      } else {
        setSettings({ ...FALLBACK_SETTINGS, ...(settingsResult.data || {}) });
        setProducts((productsResult.data || []).map((p) => ({
          ...p,
          product_images: [...(p.product_images || [])].sort((a, b) => a.sort_order - b.sort_order),
        })));
        setLoadError('');
      }
      setLoading(false);
    }
    load();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (!lightbox) return undefined;
    const closeOnEscape = (event) => { if (event.key === 'Escape') setLightbox(null); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [lightbox]);

  const categories = useMemo(() => Array.isArray(settings.category_filters) ? settings.category_filters : FALLBACK_SETTINGS.category_filters, [settings.category_filters]);
  const visibleProducts = useMemo(() => activeCategory === 'all' ? products : products.filter((p) => p.category === activeCategory), [activeCategory, products]);
  const businessName = settings.business_name || 'Spare Parts UG';
  const [brandFirst = 'Spare Parts', brandLast = 'UG'] = businessName.split(/\s+(?=[^\s]+$)/);
  const whatsappUrl = (message) => buildWhatsAppUrl(settings.whatsapp_number, message);

  const enquireProduct = (product) => {
    const message = `${settings.whatsapp_greeting || FALLBACK_SETTINGS.whatsapp_greeting}${product.name}. Is it in stock and what is the price? My car model & year: __`;
    // Open synchronously inside the tap handler so mobile browsers do not block the new tab.
    window.open(whatsappUrl(message), '_blank', 'noopener,noreferrer');
    supabase.from('product_clicks').insert({ product_id: product.id }).then(({ error }) => {
      if (error) console.warn('Product tap could not be recorded:', error.message);
    });
  };

  const schema = {
    '@context': 'https://schema.org', '@type': ['AutoPartsStore', 'LocalBusiness'],
    name: businessName, address: { '@type': 'PostalAddress', streetAddress: settings.shop_address, addressLocality: 'Kampala', addressCountry: 'UG' },
    telephone: [settings.primary_phone, settings.secondary_phone], url: typeof window !== 'undefined' ? window.location.origin : '',
  };

  return (
    <div className="storefront">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <header className="store-header">
        <div className="wrap header-inner">
          <a className="brand" href="/" aria-label={businessName}>
            {brandFirst} <span>{settings.logo_highlight || brandLast}</span>
          </a>
          <div className="header-right">
            <a className="header-cta" href={whatsappUrl(settings.general_whatsapp_message)} target="_blank" rel="noreferrer">{settings.header_cta_text}</a>
          </div>
        </div>
      </header>

      <section className="hero">
        <div className="hero-img">
          <img src={settings.hero_image_url} alt="Modern car dashboard with Android radio touchscreen" fetchPriority="high" />
          <div className="hero-overlay" />
          <div className="hero-content">
            <div className="wrap">
              <span className="hero-tag">{settings.hero_tag}</span>
              <h1>{settings.hero_title}</h1>
              <p>{settings.hero_description}</p>
              <div className="hero-actions">
                <a className="btn-red" href="#shop">{settings.hero_primary_label}</a>
                <a className="btn-outline" href={whatsappUrl(settings.hero_secondary_message)} target="_blank" rel="noreferrer">{settings.hero_secondary_label}</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="strip">
        <div className="wrap">
          <div>📍 <strong>{settings.strip_location}</strong></div>
          <div>📞 <strong><PhoneLink phone={settings.primary_phone} /> / <PhoneLink phone={settings.secondary_phone} /></strong></div>
          <div>🕗 {settings.opening_hours}</div>
        </div>
      </div>

      <section className="cats" id="shop">
        <div className="wrap">
          <div className="cat-row" role="tablist" aria-label="Product categories">
            {categories.map((cat) => <button key={cat.key} className={`cat-pill ${activeCategory === cat.key ? 'active' : ''}`} onClick={() => setActiveCategory(cat.key)} role="tab" aria-selected={activeCategory === cat.key}>{cat.label}</button>)}
          </div>
        </div>
      </section>

      <section className="products">
        <div className="wrap">
          {loadError && <div className="store-error">Live store could not be loaded: {loadError}</div>}
          {loading ? <div className="grid">{Array.from({ length: 4 }).map((_, i) => <div className="card skeleton-card" key={i}><div className="skeleton-image" /><div className="card-body"><div className="skeleton-line" /><div className="skeleton-line short" /></div></div>)}</div> : (
            <div className="grid" id="productGrid">
              {visibleProducts.map((product) => {
                const images = product.product_images || [];
                const firstImage = images[0]?.image_url || '';
                const priceText = product.price === null || product.price === undefined || product.price === '' ? settings.no_price_label : formatUGX(product.price);
                return (
                  <article className="card" key={product.id}>
                    <div className="card-img">
                      {(product.stock_status === 'out_of_stock' || product.badge_label || product.emoji_badge) && <span className="card-badge">{product.stock_status === 'out_of_stock' ? settings.out_of_stock_badge_label : (product.badge_label || product.emoji_badge)}</span>}
                      {firstImage ? <button className="product-image-button" onClick={() => setLightbox({ images, index: 0, title: product.name })} aria-label={`View photos of ${product.name}`}><img src={firstImage} alt={product.name} loading="lazy" /></button> : <div className="no-product-image">{settings.no_image_label}</div>}
                    </div>
                    <div className="card-body">
                      <span className="card-cat">{product.description || product.category}</span>
                      <h3>{product.name}</h3>
                      <div className="card-price">{priceText}<small>{settings.price_note}</small></div>
                      <button className="add-btn" onClick={() => enquireProduct(product)}><MessageCircle size={16} /> {settings.product_button_label}</button>
                    </div>
                  </article>
                );
              })}
              {!visibleProducts.length && <div className="empty-products">{settings.empty_products_label}</div>}
            </div>
          )}
        </div>
      </section>

      <section className="why">
        <div className="wrap">
          <h2>{settings.why_heading}</h2>
          <div className="why-grid">
            {(Array.isArray(settings.why_items) ? settings.why_items : FALLBACK_SETTINGS.why_items).map((item, index) => <div className="why-item" key={`${item.title}-${index}`}><h3>{item.title}</h3><p>{item.description}</p></div>)}
          </div>
        </div>
      </section>

      <footer>
        <div className="wrap">
          <div className="footer-grid">
            <div><h3>{businessName}</h3><p>{settings.footer_business_description}</p></div>
            <div><h3>{settings.footer_contact_heading}</h3><p><a href={settings.maps_url} target="_blank" rel="noreferrer">{settings.shop_address}</a><br />{settings.footer_phone_label} <PhoneLink phone={settings.primary_phone} /> / <PhoneLink phone={settings.secondary_phone} /><br />{settings.footer_hours}</p></div>
          </div>
          <div className="footer-bottom">
            <span>{settings.footer_copyright}</span>
            <span>{settings.footer_credit}</span>
            <a className="admin-footer-link" href="/admin/login">Admin</a>
          </div>
        </div>
      </footer>

      <a className="wa-float" href={whatsappUrl(settings.general_whatsapp_message)} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"><MessageCircle size={26} fill="currentColor" /></a>

      {lightbox && <div className="lightbox" role="dialog" aria-modal="true" aria-label={`${lightbox.title} photos`} onClick={() => setLightbox(null)}>
        <button className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Close image viewer"><X /></button>
        {lightbox.images.length > 1 && <button className="lightbox-nav prev" onClick={(e) => { e.stopPropagation(); setLightbox((v) => ({ ...v, index: (v.index - 1 + v.images.length) % v.images.length })); }} aria-label="Previous photo"><ChevronLeft /></button>}
        <img src={lightbox.images[lightbox.index]?.image_url} alt={`${lightbox.title} photo ${lightbox.index + 1}`} className="lightbox-image" onClick={(e) => e.stopPropagation()} />
        {lightbox.images.length > 1 && <button className="lightbox-nav next" onClick={(e) => { e.stopPropagation(); setLightbox((v) => ({ ...v, index: (v.index + 1) % v.images.length })); }} aria-label="Next photo"><ChevronRight /></button>}
        <div className="lightbox-caption">{lightbox.title}{lightbox.images.length > 1 ? ` · ${lightbox.index + 1} / ${lightbox.images.length}` : ''}</div>
      </div>}
    </div>
  );
}
