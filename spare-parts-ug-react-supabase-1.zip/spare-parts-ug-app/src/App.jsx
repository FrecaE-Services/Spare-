import React, { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { hasSupabaseConfig, supabase } from './lib/supabase';
import { AuthContext } from './lib/auth';
import PublicSite from './pages/PublicSite.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Products from './pages/Products.jsx';
import SiteContent from './pages/SiteContent.jsx';
import Account from './pages/Account.jsx';
import NotFound from './pages/NotFound.jsx';
import AdminLayout from './components/AdminLayout.jsx';
import SetupNotice from './components/SetupNotice.jsx';

function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    let alive = true;
    const loadRole = async (currentUser) => {
      setUser(currentUser || null);
      setRole(null);
      if (!currentUser) return;
      const { data, error } = await supabase.from('user_roles').select('role').eq('user_id', currentUser.id).maybeSingle();
      if (!alive) return;
      if (error) console.error('Unable to verify admin role:', error);
      setRole(data?.role === 'admin' ? 'admin' : null);
    };
    supabase.auth.getSession().then(async ({ data }) => {
      if (!alive) return;
      setSession(data.session);
      await loadRole(data.session?.user || null);
      if (alive) setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setLoading(true);
      // Defer DB reads to avoid calling Supabase during its auth callback lock.
      Promise.resolve().then(async () => {
        await loadRole(nextSession?.user || null);
        if (alive) setLoading(false);
      });
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);

  return <AuthContext.Provider value={{ session, user, role, loading }}>{children}</AuthContext.Provider>;
}

function AdminGuard({ children }) {
  const { session, role, loading } = useAuth();
  const location = useLocation();
  if (loading) return <div className="admin-loading-screen"><div className="loading-mark">SP</div><p>Checking secure admin access…</p></div>;
  if (!session) return <Navigate to="/admin/login" replace state={{ from: location.pathname }} />;
  if (role !== 'admin') return <div className="admin-denied"><h1>Access restricted</h1><p>This account does not have the administrator role.</p><button className="btn btn-dark" onClick={() => supabase?.auth.signOut()}>Sign out</button></div>;
  return children;
}

export default function App() {
  if (!hasSupabaseConfig) return <SetupNotice />;
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<PublicSite />} />
        <Route path="/admin/login" element={<Login />} />
        <Route path="/admin" element={<AdminGuard><AdminLayout /></AdminGuard>}>
          <Route index element={<Dashboard />} />
          <Route path="products" element={<Products />} />
          <Route path="content" element={<SiteContent />} />
          <Route path="account" element={<Account />} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AuthProvider>
  );
}
