import React, { useState } from 'react';
import { ImagePlus, LoaderCircle } from 'lucide-react';
import { openCloudinaryWidget } from '../lib/cloudinary';
import { toast } from 'sonner';

export default function CloudinaryUploadButton({ onUploaded, multiple = true, label = 'Add photo', folder = 'spare-parts-ug' }) {
  const [opening, setOpening] = useState(false);
  const handleOpen = () => {
    try {
      setOpening(true);
      openCloudinaryWidget({ multiple, folder, onSuccess: (asset) => { onUploaded(asset); toast.success('Photo uploaded successfully'); } });
      setOpening(false);
    } catch (error) {
      setOpening(false);
      toast.error(error.message || 'Could not open the photo uploader');
    }
  };
  return <button type="button" className="upload-trigger" onClick={handleOpen} disabled={opening}>
    {opening ? <LoaderCircle className="spin" size={17} /> : <ImagePlus size={17} />}{label}
  </button>;
}
