import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Package, FileText, UserRound, LogOut, ExternalLink } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import { toast } from 'sonner';

const navItems = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/products', label: 'Products', icon: Package },
  { to: '/admin/content', label: 'Site content', icon: FileText },
  { to: '/admin/account', label: 'Account', icon: UserRound },
];

export default function AdminLayout() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) toast.error(error.message);
    else { toast.success('Signed out successfully'); navigate('/admin/login', { replace: true }); }
  };
  return <div className="admin-shell">
    <aside className="admin-sidebar">
      <a href="/" className="admin-brand"><span className="admin-brand-mark">SP</span><span>SPARE PARTS <b>UG</b><small>CONTROL PANEL</small></span></a>
      <nav className="admin-nav">{navItems.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}><Icon size={18} /><span>{label}</span></NavLink>)}</nav>
      <div className="sidebar-bottom"><a href="/" target="_blank" rel="noreferrer"><ExternalLink size={16} /> View public site</a><button onClick={signOut}><LogOut size={16} /> Sign out</button></div>
    </aside>
    <main className="admin-main">
      <header className="admin-topbar"><div><span className="admin-top-kicker">SPARE PARTS UG / MANAGEMENT</span><div className="admin-top-title">Store administration</div></div><div className="admin-user-chip"><span className="user-avatar">{user?.email?.slice(0, 1).toUpperCase() || 'A'}</span><span>{user?.email}</span></div></header>
      <div className="admin-page"><Outlet /></div>
      <nav className="admin-mobile-nav">{navItems.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => isActive ? 'active' : ''}><Icon size={19} /><span>{label}</span></NavLink>)}<button onClick={signOut}><LogOut size={19} /><span>Sign out</span></button></nav>
    </main>
  </div>;
}
