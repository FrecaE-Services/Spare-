import React from 'react';
export default function SetupNotice() {
  return <main className="setup-notice"><div className="setup-mark">SP</div><p className="setup-kicker">SPARE PARTS UG</p><h1>Connect your Supabase project</h1><p>The app source is ready. Add your Supabase project URL and anon key to a local <code>.env</code> file, then run the SQL setup in <code>supabase/schema.sql</code>.</p><pre>cp .env.example .env</pre><p className="setup-muted">No admin credentials or service-role keys are embedded in this frontend.</p></main>;
}
