import React from 'react';
import { AlertTriangle } from 'lucide-react';
export default function ConfirmDialog({ open, title = 'Are you sure?', message, confirmLabel = 'Delete', onConfirm, onCancel, busy = false }) {
  if (!open) return null;
  return <div className="modal-backdrop confirm-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onCancel(); }}>
    <section className="confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
      <div className="confirm-icon"><AlertTriangle size={22} /></div><h2 id="confirm-title">{title}</h2><p>{message}</p>
      <div className="modal-actions"><button className="btn btn-light" onClick={onCancel} disabled={busy}>Cancel</button><button className="btn btn-danger" onClick={onConfirm} disabled={busy}>{busy ? 'Working…' : confirmLabel}</button></div>
    </section>
  </div>;
}
