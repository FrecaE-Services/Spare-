-- Spare Parts UG — Supabase schema and policies
-- Run once in Supabase SQL Editor after creating a new project.
-- This app uses public/anon reads, anonymous click inserts, and database-verified admin privileges.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  category text not null default 'body',
  emoji_badge text not null default '',
  badge_label text not null default '',
  price numeric(14,0) null check (price is null or price >= 0),
  stock_status text not null default 'in_stock' check (stock_status in ('in_stock','out_of_stock')),
  visible boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  image_url text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id uuid primary key default gen_random_uuid(),
  singleton boolean not null default true unique check (singleton),
  business_name text not null default 'Spare Parts UG',
  logo_highlight text not null default 'UG',
  header_cta_text text not null default 'Enquire',
  hero_tag text not null default 'No.1 Automotive Spare Parts Mega Store',
  hero_title text not null default 'Your Reliable Auto Parts Partner.',
  hero_description text not null default 'Car facelifting, body parts, Android radios, security systems, and every accessory in between — genuine parts, fitted to your exact model.',
  hero_image_url text not null default 'https://images.unsplash.com/photo-1648892936786-de40bb1080a6?w=1200&auto=format&fit=crop&q=80',
  hero_primary_label text not null default 'Shop Parts',
  hero_secondary_label text not null default 'Ask a Specialist',
  hero_secondary_message text not null default 'Hi Spare Parts UG, I need help finding a part',
  strip_location text not null default 'William Street, Kampala',
  primary_phone text not null default '0774 188097',
  secondary_phone text not null default '0752 127553',
  opening_hours text not null default 'Open 8:30 AM – 6:00 PM',
  shop_address text not null default 'William Street, Kampala, Uganda',
  footer_hours text not null default 'Open Mon–Sat, 8:30 AM – 6:00 PM',
  footer_business_description text not null default 'Your reliable auto parts partner for quality car parts, facelifts, and accessories.',
  footer_credit text not null default 'Site by FRECA E-SERVICES — Frontend Demo',
  footer_copyright text not null default '© 2026 Spare Parts UG',
  whatsapp_number text not null default '256774188097',
  whatsapp_greeting text not null default 'Hi Spare Parts UG! I saw your website. I am interested in: ',
  general_whatsapp_message text not null default 'Hi Spare Parts UG, I''d like to enquire',
  maps_url text not null default 'https://www.google.com/maps/search/?api=1&query=William+Street+Kampala+Uganda',
  price_note text not null default 'Sample listing — confirm with real menu',
  no_price_label text not null default 'Contact for price',
  product_button_label text not null default 'Enquire on WhatsApp',
  no_image_label text not null default 'No image available',
  empty_products_label text not null default 'No parts are listed in this category yet.',
  out_of_stock_badge_label text not null default 'Out of Stock',
  footer_contact_heading text not null default 'Visit / Contact',
  footer_phone_label text not null default 'Call / WhatsApp:',
  category_filters jsonb not null default '[{"key":"all","label":"All Parts"},{"key":"radios","label":"Android / CarPlay Radios"},{"key":"body","label":"Car Body Parts"},{"key":"security","label":"Security Systems"},{"key":"facelift","label":"Facelift Body Kits"}]'::jsonb,
  why_heading text not null default 'Why Spare Parts UG',
  why_items jsonb not null default '[{"title":"Model-Specific Fit","description":"Radios and parts listed by exact make, model, and year — no guesswork."},{"title":"3,000+ Followers Strong","description":"A trusted name across Kampala for facelifts, body parts, and upgrades."},{"title":"One Stop Shop","description":"From headlamps to GPS trackers — everything your car needs, in one place."}]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.product_clicks (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin')),
  created_at timestamptz not null default now()
);

-- Ensure only one admin role can exist at a time.
create unique index if not exists user_roles_single_admin_idx
  on public.user_roles (role) where role = 'admin';

create index if not exists products_visible_sort_idx on public.products (visible, sort_order);
create index if not exists product_images_product_sort_idx on public.product_images (product_id, sort_order);
create index if not exists product_clicks_created_idx on public.product_clicks (created_at desc);
create index if not exists product_clicks_product_idx on public.product_clicks (product_id);

-- Role check runs with function owner privileges to avoid recursive RLS on user_roles.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.user_roles ur
    where ur.user_id = (select auth.uid())
      and ur.role = 'admin'
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.site_settings enable row level security;
alter table public.product_clicks enable row level security;
alter table public.user_roles enable row level security;

-- Public website can read visible products only; administrators can read all products.
drop policy if exists "Public can read visible products" on public.products;
create policy "Public can read visible products" on public.products
  for select to anon, authenticated
  using (visible or (select public.is_admin()));
drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- Images belonging to visible products are public. Admins can manage all images.
drop policy if exists "Public can read images for visible products" on public.product_images;
create policy "Public can read images for visible products" on public.product_images
  for select to anon, authenticated
  using (
    exists (
      select 1 from public.products p
      where p.id = product_images.product_id and p.visible = true
    ) or (select public.is_admin())
  );
drop policy if exists "Admins manage product images" on public.product_images;
create policy "Admins manage product images" on public.product_images
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- The singleton site settings row is public-readable and admin-editable.
drop policy if exists "Anyone can read site settings" on public.site_settings;
create policy "Anyone can read site settings" on public.site_settings
  for select to anon, authenticated using (true);
drop policy if exists "Admins manage site settings" on public.site_settings;
create policy "Admins manage site settings" on public.site_settings
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- Visitors may insert one click record for a visible product; there is no public SELECT/UPDATE/DELETE.
drop policy if exists "Anyone can record visible product clicks" on public.product_clicks;
create policy "Anyone can record visible product clicks" on public.product_clicks
  for insert to anon, authenticated
  with check (
    exists (
      select 1 from public.products p
      where p.id = product_clicks.product_id and p.visible = true
    )
  );
drop policy if exists "Admins can read product clicks" on public.product_clicks;
create policy "Admins can read product clicks" on public.product_clicks
  for select to authenticated
  using ((select public.is_admin()));

-- An account may read its own role row; all role writes are intentionally withheld from browser clients.
drop policy if exists "Users can read their own role" on public.user_roles;
create policy "Users can read their own role" on public.user_roles
  for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

-- API grants. RLS remains the authorization layer.
grant usage on schema public to anon, authenticated;
grant select on public.products, public.product_images, public.site_settings to anon, authenticated;
grant insert, update, delete on public.products, public.product_images, public.site_settings to authenticated;
grant insert on public.product_clicks to anon, authenticated;
grant select on public.product_clicks to authenticated;
grant select on public.user_roles to authenticated;

-- Seed the exact eight listings and the exact card image URLs from spare-parts-ug-demo.html.
insert into public.site_settings (singleton) values (true)
on conflict (singleton) do nothing;

insert into public.products (name, description, category, emoji_badge, badge_label, price, stock_status, visible, sort_order)
select v.name, v.description, v.category, '', v.badge_label, null, 'in_stock', true, v.sort_order
from (values
  ('Prado FJ150 9" Android Radio', 'Android / CarPlay Radio', 'radios', 'Popular', 1),
  ('Mark X 2010–2023 9" Radio', 'Android / CarPlay Radio', 'radios', '', 2),
  ('Subaru Forester Headlamps / Taillights', 'Car Body Parts', 'body', 'In Stock', 3),
  ('Hilux Vigo Headlamps / Rearlamps', 'Car Body Parts', 'body', '', 4),
  ('Keyless Entry System', 'Security System', 'security', '', 5),
  ('Car GPS Tracker', 'Security System', 'security', 'Order Now', 6),
  ('Landcruiser V8 Facelift Kit', 'Facelift Body Kit', 'facelift', '', 7),
  ('Mark X Facelift Front Bumper', 'Facelift Body Kit', 'facelift', '', 8)
) as v(name, description, category, badge_label, sort_order)
where not exists (select 1 from public.products);

insert into public.product_images (product_id, image_url, sort_order)
select p.id, v.image_url, 0
from public.products p
join (values
  ('Prado FJ150 9" Android Radio', 'https://images.unsplash.com/photo-1648892936786-de40bb1080a6?w=600&auto=format&fit=crop&q=80'),
  ('Mark X 2010–2023 9" Radio', 'https://images.unsplash.com/photo-1648892936786-de40bb1080a6?w=600&auto=format&fit=crop&q=80&sat=-20'),
  ('Subaru Forester Headlamps / Taillights', 'https://images.unsplash.com/photo-1557775209-a640976a712f?w=600&auto=format&fit=crop&q=80'),
  ('Hilux Vigo Headlamps / Rearlamps', 'https://images.unsplash.com/photo-1557775209-a640976a712f?w=600&auto=format&fit=crop&q=80&sat=-40'),
  ('Keyless Entry System', 'https://images.unsplash.com/photo-1710006548781-eff5670376fa?w=600&auto=format&fit=crop&q=80'),
  ('Car GPS Tracker', 'https://images.unsplash.com/photo-1710006548781-eff5670376fa?w=600&auto=format&fit=crop&q=80&sat=-30'),
  ('Landcruiser V8 Facelift Kit', 'https://images.unsplash.com/photo-1557775209-a640976a712f?w=600&auto=format&fit=crop&q=80&hue=200'),
  ('Mark X Facelift Front Bumper', 'https://images.unsplash.com/photo-1557775209-a640976a712f?w=600&auto=format&fit=crop&q=80&hue=280')
) as v(name, image_url) on p.name = v.name
where not exists (select 1 from public.product_images pi where pi.product_id = p.id);

-- After creating the admin user in Supabase Authentication, run this statement once:
-- insert into public.user_roles (user_id, role)
-- select id, 'admin' from auth.users where email = 'sparepartsug112@gmail.com'
-- on conflict (user_id) do update set role = excluded.role;
