-- Run AFTER creating the owner account in Supabase Auth > Users.
-- This grants the single administrator role to the configured email address.
do $$
declare
  target_user_id uuid;
begin
  select id into target_user_id
  from auth.users
  where lower(email) = lower('sparepartsug112@gmail.com')
  limit 1;

  if target_user_id is null then
    raise exception 'Admin account not found. Create the Auth user first, then rerun this script.';
  end if;

  delete from public.user_roles
  where role = 'admin' and user_id <> target_user_id;

  insert into public.user_roles (user_id, role)
  values (target_user_id, 'admin')
  on conflict (user_id) do update set role = excluded.role;
end $$;
