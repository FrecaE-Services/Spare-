-- Policy inventory and privilege check. Run from Supabase SQL Editor as project owner.
-- This verifies that the expected policies/grants exist; also execute the live-role tests in README.md.

select
  tablename,
  policyname,
  roles,
  cmd,
  permissive,
  qual,
  with_check
from pg_policies
where schemaname = 'public'
  and tablename in ('products', 'product_images', 'site_settings', 'product_clicks', 'user_roles')
order by tablename, cmd, policyname;

select
  has_table_privilege('anon', 'public.products', 'SELECT') as anon_can_select_products,
  has_table_privilege('anon', 'public.products', 'INSERT') as anon_can_insert_products,
  has_table_privilege('anon', 'public.products', 'UPDATE') as anon_can_update_products,
  has_table_privilege('anon', 'public.products', 'DELETE') as anon_can_delete_products,
  has_table_privilege('anon', 'public.product_clicks', 'INSERT') as anon_can_insert_clicks,
  has_table_privilege('anon', 'public.product_clicks', 'SELECT') as anon_can_select_clicks;

select role, count(*) as role_count
from public.user_roles
group by role;
